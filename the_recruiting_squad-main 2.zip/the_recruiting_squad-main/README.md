# THE RECRUITING SQUAD (update)
*********************************************************************************
* Banner
* candidates
* create_employer_account
* forget_password
* jobs
* login_after_reset
* login_page
* reset_pass
* sign_up
* compensation
* job_description
* include_details
* Basic_info
* confirm_account_details
* schedule_kickoff_meeting
* share_resume
* view_resume
* add_a_note
* add_a_note_existing
* messages

* add_a_note_dialog
* messages_write_a_message
* footer_signup
* navbar_footer
